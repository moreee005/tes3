package data.model;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
  private String id;
  private String account;
  private String pin;
  private String fullName;
  private BigDecimal balance;
  private Integer invalidTries;
  private BigDecimal dailyWithdrawnAmount; // Tambahkan properti ini

  /**
   * Use this function to add balance to Customer
   *
   * @param amount
   */
  public void add(BigDecimal amount) {
    this.balance = this.balance.add(amount);
  }

  /**
   * Use this function to subtract balance from Customer
   *
   * @param amount
   */
  public void subtract(BigDecimal amount) {
    this.balance = this.balance.subtract(amount);
  }

  /**
   * Use this function to add to daily withdrawn amount
   *
   * @param amount
   */
  public void addToDailyWithdrawnAmount(BigDecimal amount) {
    if (this.dailyWithdrawnAmount == null) {
      this.dailyWithdrawnAmount = BigDecimal.ZERO;
    }
    this.dailyWithdrawnAmount = this.dailyWithdrawnAmount.add(amount);
  }
}
