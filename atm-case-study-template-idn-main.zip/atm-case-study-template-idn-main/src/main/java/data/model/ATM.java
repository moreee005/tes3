package data.model;

import java.math.BigDecimal;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Setter(AccessLevel.NONE)
public class ATM {
  private String id;
  private BigDecimal balance;
  private Bank bank;

  /**
   * Use this function to subtract balance from ATM.
   * Ensures that balance does not become negative.
   *
   * @param amount The amount to subtract from the balance.
   * @throws IllegalArgumentException if the amount is negative or if it would result in a negative balance.
   */
  public synchronized void subtract(BigDecimal amount) {
    if (amount.compareTo(BigDecimal.ZERO) < 0) {
      throw new IllegalArgumentException("Amount to subtract cannot be negative.");
    }
    if (this.balance.compareTo(amount) < 0) {
      throw new IllegalArgumentException("Insufficient balance for the subtraction.");
    }
    this.balance = this.balance.subtract(amount);
  }

  /**
   * Sets the balance, ensuring it is not negative.
   *
   * @param balance The new balance.
   * @throws IllegalArgumentException if the balance is negative.
   */
  public void setBalance(BigDecimal balance) {
    if (balance.compareTo(BigDecimal.ZERO) < 0) {
      throw new IllegalArgumentException("Balance cannot be negative.");
    }
    this.balance = balance;
  }

  // Optionally, add a method to increase the balance if needed
  /**
   * Use this function to add balance to ATM.
   *
   * @param amount The amount to add to the balance.
   * @throws IllegalArgumentException if the amount is negative.
   */
  public synchronized void addBalance(BigDecimal amount) {
    if (amount.compareTo(BigDecimal.ZERO) < 0) {
      throw new IllegalArgumentException("Amount to add cannot be negative.");
    }
    this.balance = this.balance.add(amount);
  }
  public synchronized void withdraw(BigDecimal amount) {
    if (amount.compareTo(BigDecimal.ZERO) < 0) {
      throw new IllegalArgumentException("Amount to withdraw cannot be negative.");
    }
    if (this.balance.compareTo(amount) < 0) {
      throw new IllegalArgumentException("Insufficient balance for the withdrawal.");
    }
    this.balance = this.balance.subtract(amount);
  }

}
