package data.constant;

public enum TransactionType {
  WITHDRAWAL,
  TOP_UP,

  ;
}
