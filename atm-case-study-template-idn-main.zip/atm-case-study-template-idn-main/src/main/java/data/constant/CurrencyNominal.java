package data.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CurrencyNominal {
  M10K,
  M20K,
  M50K,
  M100K,

  ;
}
