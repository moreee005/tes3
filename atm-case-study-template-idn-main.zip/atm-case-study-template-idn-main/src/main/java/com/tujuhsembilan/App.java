package com.tujuhsembilan;

import java.util.Arrays;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.tujuhsembilan.logic.ATMLogic;
import com.tujuhsembilan.logic.ConsoleUtil;
import data.constant.BankCompany;
import data.model.ATM;
import data.model.Bank;
import data.repository.ATMRepo;
import data.repository.BankRepo;

import static com.tujuhsembilan.logic.ConsoleUtil.*;

public class App {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        boolean loop = true;
        while (loop) {
            printClear();
            printDivider();
            int num = 1;
            for (String menu : Arrays.stream(BankCompany.values())
                    .map(item -> "ATM " + item.getName())
                    .collect(Collectors.toList())) {
                System.out.println(" " + num + ". " + menu);
                num++;
            }
            System.out.println(" 0. EXIT");
            printDivider();

            System.out.print(" > ");
            int selection = in.nextInt();
            in.nextLine();
            if (selection > 0 && selection <= BankCompany.values().length) {
                new App(BankCompany.getByOrder(selection - 1).getName()).start(in);
            } else if (selection == 0) {
                loop = false;
            } else {
                System.out.println("Input tidak valid");
                delay();
            }
        }
    }

    final Bank bank;
    final ATM atm;

    public App(String bankName) {
        Bank lBank = null;
        ATM lAtm = null;

        Optional<Bank> qBank = BankRepo.findBankByName(bankName);
        if (qBank.isPresent()) {
            Optional<ATM> qAtm = ATMRepo.findATMByBank(qBank.get());
            if (qAtm.isPresent()) {
                lBank = qBank.get();
                lAtm = qAtm.get();
            }
        }

        this.bank = lBank;
        this.atm = lAtm;
    }

    public void start(Scanner in) {
        if (bank != null && atm != null) {
            ATMLogic.login(in, bank.getName());
            boolean userLoop = true;
            while (userLoop) {
                printClear();
                printDivider();
                System.out.println("1. Informasi Saldo");
                System.out.println("2. Tarik Uang");
                System.out.println("3. Isi Ulang Pulsa Telepon");
                System.out.println("4. Token Tagihan Listrik");

                if (bank.getName() == "BNI" || bank.getName() == "Mandiri") {
                    System.out.println("5. Mutasi Rekening (Transfer Dana)");
                }
                System.out.println("6. Deposit Uang");
                System.out.println("0. Kembali");
                printDivider();
                System.out.print(" > ");
                int choice = in.nextInt();
                in.nextLine();

                switch (choice) {
                    case 1:
                        ConsoleUtil.showSaldo(bank.getName());
                        break;
                    case 2:
                        ATMLogic.moneyWithdrawal(in, bank.getName());
                        break;
                    case 3:
                        ATMLogic.phoneCreditsTopUp(in, bank.getName());
                        break;
                    case 4:
                        ATMLogic.electricityBillsToken(in, bank.getName());
                        break;
                     case 5:
                         if (bank.getName() == "BNI" || bank.getName() == "Mandiri") {
                             ATMLogic.accountMutation(in, bank.getName());
                         }else {
                             System.out.println("Fitur ini hanya untuk BNI dan Mandiri");
                         }
                         break;
                    case 6:

                        ATMLogic.moneyDeposit(in, bank.getName());
                         break;
                    case 0:
                        userLoop = false;
                        break;
                    default:
                        System.out.println("Input tidak valid");
                        delay();
                        break;
                }
            }
        } else {
            System.out.println("Bank atau ATM tidak dapat ditemukan");
            delay();
        }
    }
}
