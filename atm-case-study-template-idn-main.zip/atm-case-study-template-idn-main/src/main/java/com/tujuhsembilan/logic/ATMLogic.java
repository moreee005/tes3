package com.tujuhsembilan.logic;

import data.model.ATM;
import data.model.Bank;
import data.model.Customer;
import data.repository.BankRepo;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.text.NumberFormat;
import java.util.*;

public class ATMLogic {
  private static final BigDecimal MAX_WITHDRAWAL_PER_TRANSACTION = new BigDecimal(2500000);
  private static final BigDecimal MAX_DAILY_WITHDRAWAL_LIMIT = new BigDecimal(5000000);
  private static final BigDecimal MULTIPLE_OF_AMOUNT = new BigDecimal(10000);

  public static void login(Scanner in, String bankName) {

    Optional<Bank> bankOptional = BankRepo.findBankByName(bankName);
    Set<Bank> allBanks = BankRepo.getAllBanks();


    if (bankOptional.isPresent()) {
      Bank bank = bankOptional.get();
      int attemptCount = 0;

      while (attemptCount < 3) {
        System.out.println("Masukkan rek");
        String rek = in.nextLine();
        System.out.println("Masukkan pin");
        String pin = in.nextLine();

        boolean loginSuccess = false;

        for (Customer customer : bank.getCustomers()) {
          if (customer.getAccount().equals(rek) && customer.getPin().equals(pin)) {
            System.out.println("Login berhasil");
            loginSuccess = true;
            break;
          }
        }

        if (loginSuccess) {
          break;
        } else {
          attemptCount++;
          if (attemptCount < 3) {
            System.out.println("Login gagal, silakan coba lagi.");
          } else {
            System.out.println("Login gagal 3 kali. Silakan coba lagi nanti.");
          }
        }
      }
    } else {
      System.out.println("Bank dengan nama " + bankName + " tidak ditemukan.");
      System.exit(0);
    }


  }

  public static void accountMutation(Scanner in, String bankName) {
    final BigDecimal ADMIN_FEE = BigDecimal.valueOf(2500);

    System.out.println("Masukkan nomor rekening tujuan:");
    String noPelanggan = in.nextLine().trim();

    System.out.println("Masukkan jumlah uang yang ingin dideposit: ");
    BigDecimal deposit = in.nextBigDecimal();
    in.nextLine();

    Optional<Bank> bankOptional = BankRepo.findBankByName(bankName);


    if (!bankOptional.isPresent()) {
      System.out.println("Bank dengan nama " + bankName + " tidak ditemukan.");
      return;
    }

    Bank bank1 = bankOptional.get();
    Set<Bank> allBanks = BankRepo.getAllBanks();

    boolean customerFound = false;
    for (Customer customer : bank1.getCustomers()) {
      customer.setBalance(customer.getBalance().subtract(deposit));
    }

    for (Bank bank : allBanks) {
      Optional<Customer> customerOptional = bank.getCustomers().stream()
              .filter(customer -> customer.getAccount().equals(noPelanggan))
              .findFirst();

      if (customerOptional.isPresent()) {
        Customer customer = customerOptional.get();

        if (!bank.getName().equals(bank1.getName())) {
          for (Customer customer1 : bank1.getCustomers()) {
            customer1.setBalance(customer1.getBalance().subtract(ADMIN_FEE));
          }
          System.out.println("Biaya admin sebesar " + formatRupiah(ADMIN_FEE) + " telah dikenakan karena bank berbeda.");
        }

        if (deposit.compareTo(BigDecimal.ZERO) > 0) {
          customer.setBalance(customer.getBalance().add(deposit));
          System.out.println("Deposit ke akun " + noPelanggan + " berhasil sebesar " + formatRupiah(deposit));

        } else {
          System.out.println("Deposit gagal karena jumlah setelah biaya admin kurang dari atau sama dengan nol.");
        }

        customerFound = true;
        break;
      }
    }

    if (!customerFound) {
      System.out.println("Pelanggan dengan nomor " + noPelanggan + " tidak ditemukan di semua bank.");
    }
  }



  public static void accountBalanceInformation() {
    // Implementasi method ini
  }

  public static void moneyWithdrawal(Scanner in, String bankName) {
    System.out.print("Masukkan jumlah uang yang ingin ditarik: Rp");
    Optional<Bank> bankOptional = BankRepo.findBankByName(bankName);
    if (!bankOptional.isPresent()) {
      System.out.println("Bank dengan nama " + bankName + " tidak ditemukan.");
      return;
    }
    Bank bank = bankOptional.get();
    BigDecimal rp = in.nextBigDecimal();

    if (rp.remainder(MULTIPLE_OF_AMOUNT).compareTo(BigDecimal.ZERO) != 0) {
      System.out.println("Penarikan hanya dapat dilakukan dalam kelipatan Rp10.000,00.");
      return;
    }

    if (rp.compareTo(MAX_WITHDRAWAL_PER_TRANSACTION) > 0) {
      System.out.println("Jumlah maksimum per transaksi adalah Rp2.500.000,00.");
      return;
    }

    for (Customer customer : bank.getCustomers()) {
      BigDecimal totalWithdrawnToday = customer.getDailyWithdrawnAmount();
      if (totalWithdrawnToday == null) {
        totalWithdrawnToday = BigDecimal.ZERO;
      }

      if (totalWithdrawnToday.add(rp).compareTo(MAX_DAILY_WITHDRAWAL_LIMIT) > 0) {
        System.out.println("Jumlah maksimum transaksi harian per rekening adalah Rp5.000.000,00.");
        return;
      }

      customer.subtract(rp);
      customer.addToDailyWithdrawnAmount(rp);
      System.out.println("Penarikan berhasil.");
      System.out.println("Saldo saat ini: " + formatRupiah(customer.getBalance()));
      return;
    }
  }

  public static void phoneCreditsTopUp(Scanner in, String bankName) {
    System.out.println("Masukkan No ");
    int noHp = in.nextInt();

    System.out.print("Rp10.000,00\n" +
            "Rp20.000,00\n" +
            "Rp50.000,00\n" +
            "Rp100.000,00\n");

    Optional<Bank> bankOptional = BankRepo.findBankByName(bankName);
    Bank bank = bankOptional.get();
    System.out.println("Pilih 1-4");
    int swit = in.nextInt();
    BigDecimal pulsa;
    switch (swit) {
      case 1:
        pulsa = new BigDecimal(10000);
        break;
      case 2:
        pulsa = new BigDecimal(20000);
        break;
      case 3:
        pulsa = new BigDecimal(50000);
        break;
      case 4:
        pulsa = new BigDecimal(100000);
        break;
      default:
        System.out.println("Pilihan tidak valid.");
        return;
    }

    for (Customer customer : bank.getCustomers()) {
      customer.setBalance(customer.getBalance().subtract(pulsa));
      System.out.println("Top-up ke " + noHp + " berhasil sebesar " + formatRupiah(pulsa));
      System.out.println("Sisa saldo " + formatRupiah(customer.getBalance()));
      break;
    }

  }

  public static void electricityBillsToken(Scanner in, String bankName) {
    System.out.println("Masukkan No Pelanggan");
    int noPelanggan = in.nextInt();

    System.out.print("Rp50.000,00\n" +
            "Rp100.000,00\n" +
            "Rp200.000,00\n" +
            "Rp500.000,00\n");

    Optional<Bank> bankOptional = BankRepo.findBankByName(bankName);
    Bank bank = bankOptional.get();
    System.out.println("Pilih 1-4");
    int swit = in.nextInt();
    BigDecimal token;
    switch (swit) {
      case 1:
        token = new BigDecimal(50000);
        break;
      case 2:
        token = new BigDecimal(100000);
        break;
      case 3:
        token = new BigDecimal(200000);
        break;
      case 4:
        token = new BigDecimal(500000);
        break;
      default:
        System.out.println("Pilihan tidak valid.");
        return;
    }
    String tokenM = TokenGenerator.generateToken();

    for (Customer customer : bank.getCustomers()) {
      customer.setBalance(customer.getBalance().subtract(token));
      System.out.println("Top-up ke " + noPelanggan + " berhasil sebesar " + formatRupiah(token));
      System.out.println("Token : " + tokenM);
      System.out.println("Sisa saldo " + formatRupiah(customer.getBalance()));
      break;
    }
  }




  public static void moneyDeposit(Scanner in, String bankName) {
    System.out.println("Masukkan jumlah uang yang ingin dideposit: ");
    BigDecimal deposit = in.nextBigDecimal();

    Optional<Bank> bankOptional = BankRepo.findBankByName(bankName);
    Bank bank = bankOptional.get();
    if (deposit.remainder(MULTIPLE_OF_AMOUNT).compareTo(BigDecimal.ZERO) != 0) {
      System.out.println("Penarikan hanya dapat dilakukan dalam kelipatan Rp10.000,00.");
      return;
    }

    for (Customer customer : bank.getCustomers()) {
      customer.setBalance(customer.getBalance().add(deposit));
      System.out.println("Top-up berhasil sebesar " + formatRupiah(deposit));

      System.out.println("Sisa saldo " + formatRupiah(customer.getBalance()));
      break;
    }

  }

  private static String formatRupiah(BigDecimal amount) {
    NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
    return nf.format(amount);
  }

  public static class TokenGenerator {
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int TOKEN_LENGTH = 16;
    private static final SecureRandom random = new SecureRandom();

    public static String generateToken() {
      StringBuilder token = new StringBuilder(TOKEN_LENGTH);
      for (int i = 0; i < TOKEN_LENGTH; i++) {
        int index = random.nextInt(CHARACTERS.length());
        token.append(CHARACTERS.charAt(index));
      }
      return token.toString();
    }
  }
}
