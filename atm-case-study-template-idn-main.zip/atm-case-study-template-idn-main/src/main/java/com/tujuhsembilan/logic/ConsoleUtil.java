package com.tujuhsembilan.logic;

import data.model.Bank;
import data.model.Customer;
import data.repository.BankRepo;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Optional;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class ConsoleUtil {

  public static final Scanner in = new Scanner(System.in);

  public static void printClear() {
    System.out.print("\033[H\033[2J");
    System.out.flush();
  }

  public static void printDivider(Character character) {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < 35; i++) {
      sb.append(character);
    }
    System.out.println(sb.toString());
  }

  public static void printDivider() {
    printDivider('=');
  }

  public static void delay(int seconds) {
    try {
      TimeUnit.SECONDS.sleep(seconds);
    } catch (InterruptedException e) {
      e.printStackTrace();
      Thread.currentThread().interrupt();
    }
  }

  public static void delay() {
    delay(3);
  }
  public static void showSaldo(String bankName) {
    Optional<Bank> bankOptional = BankRepo.findBankByName(bankName);
    if (bankOptional.isPresent()) {
      Bank bank = bankOptional.get();
      NumberFormat rupiahFormat = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));

      for (Customer customer : bank.getCustomers()) {
        String formattedBalance = rupiahFormat.format(customer.getBalance());
        System.out.println("Saldo Anda saat ini: " + formattedBalance);
      }
    } else {
      System.out.println("Bank dengan nama tersebut tidak ditemukan.");
    }
  }


}
